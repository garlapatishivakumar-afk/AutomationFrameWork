﻿using System.Text.Json;
using AIAutomationGenerator.AI.Contracts;
using AIAutomationGenerator.Interfaces;
using AIAutomationGenerator.Models;

namespace AIAutomationGenerator.AI;

public class OpenAIResponseDeserializer : IAIResponseDeserializer
{
    public AIResponse Deserialize(string response)
    {
        OpenAIChatResponse? chatResponse =
            JsonSerializer.Deserialize<OpenAIChatResponse>(response);

        if (chatResponse == null ||
            chatResponse.Choices.Count == 0)
        {
            return new AIResponse
            {
                Success = false,
                ErrorMessage = "Invalid OpenAI response."
            };
        }

        return new AIResponse
        {
            Success = true,
            Content = chatResponse.Choices[0].Message.Content,
            Usage = new AIUsageMetrics
            {
                Provider = "OpenAI",
                Model = chatResponse.Model,
                PromptTokens = chatResponse.Usage?.PromptTokens ?? 0,
                CompletionTokens = chatResponse.Usage?.CompletionTokens ?? 0,
                TotalTokens = chatResponse.Usage?.TotalTokens ?? 0
            }
        };
    }
}
